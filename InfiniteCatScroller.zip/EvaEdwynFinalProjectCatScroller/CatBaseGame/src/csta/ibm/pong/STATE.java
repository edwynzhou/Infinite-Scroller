package csta.ibm.pong;

public enum STATE {
    MENU,
    MAIN_GAME,
    MINIGAME_1,
    MINIGAME_2
}
