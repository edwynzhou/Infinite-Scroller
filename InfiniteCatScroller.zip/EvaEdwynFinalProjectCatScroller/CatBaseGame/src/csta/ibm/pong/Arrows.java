/**
 * Eva Zhang
 * Arrows Object Class
 * ICS4U1 Final Project
 * Jan 22 2023
 */

package csta.ibm.pong;

public class Arrows extends GameObject{
    @Override
    public void act() {
        setX(getX());
        setY(getY());

    }

    /*
     * falling objects and resets object to original position
     */
    public void fall() {
        setY(getY() + 10);
    }
    public void reset() {
        setX(0);
        setY(0);
    }
}