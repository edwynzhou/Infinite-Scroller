/**
 * Edwyn Zhou
 * Obstacle Object Class
 * ICS4U1 Final Project
 * Jan 22 2023
 */

package csta.ibm.pong;

import java.awt.*;

public class Obstacle extends GameObject{
    private static int dx = -15, dy = 0;
    private boolean move = true;

    public Obstacle(int x, int y, int sizeX, int sizeY, Color color){
        setX(x);
        setY(y);
        setSize(sizeX, sizeY);
        setColor(color);
    }

    public void act() {
        if (move){
            setX(getX() + dx);
        }
    }

    /**
     * Description: Increments speed variable "dx" to be more negative, making obstacles move faster towards cat
     */
    public static void setSpeed(){
        dx -= 3;
    }

    /**
     * Description: Modifies boolean state of whether or not obstacles are moving
     * @param b true if moving, false if not moving
     */
    public void setMove(boolean b){
        move = b;
    }

    /**
     * Description: Returns x value location of obstacle
     * @return integer value of obstacle location on x-axis
     */
    public int getObstacleX(){
        return getX();
    }

    /**
     * Description: Returns y value location of obstacle
     * @return integer value of obstacle location on y-axis
     */
    public int getObstacleY(){
        return getY();
    }
}
