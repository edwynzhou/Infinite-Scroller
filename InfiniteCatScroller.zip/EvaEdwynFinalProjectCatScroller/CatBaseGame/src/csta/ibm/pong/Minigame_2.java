/**
 * Eva Zhang
 * Minigame 2 (Duck Game)
 * ICS4U1 Final Project
 * Jan 22 2023
 */

package csta.ibm.pong;
import javax.swing.*;
import java.awt.*;
import java.io.*;


public class Minigame_2 extends Game{

    private JLabel counterLabel;

    private JLabel timerLabel;
    private ShootDucks ducks;
    final int MENU_BAR_HEIGHT = 40;
    private int count = 0;
    private int minigame2Timer = 300;

    public enum STATE {
        MENU,
        MINIGAME_2,
        MAIN_GAME;
    }

    STATE gameState = STATE.MENU;
    private ImageIcon minigame2Background;
    private JLabel minigame2BackgroundLabel;
    private JLabel minigameDuckLabel;
    ImageIcon gameIcon = new ImageIcon("GameIcon.png");
    private boolean playerWin = false;
    public boolean isGameOver = false;

    @Override
    public void act() {
        if (gameState == STATE.MENU) {
            try {
                startGame();
                showMainMenu();

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

        minigame2BackgroundLabel.setVisible(true);
        counterLabel.setVisible(true);
        timerLabel.setVisible(true);
        counterLabel.setText("Counter: " + count);
        /*
         * Before the time reaches 0 and the user has clicked on <5 birds,
         * The duck object with the duckLabel inscribed on it will shoot across the screen
         * if the player hits the duck object before the timer reaches 0, the timer will reset and so will the position of the duck object
         */
        if (gameState == STATE.MINIGAME_2) {
            if (minigame2Timer > 0 && count < 5) {
                minigameDuckLabel.setVisible(true);
                minigameDuckLabel.setBounds(ducks.getX() - ducks.getHeight(), ducks.getY() - ducks.getWidth(), 70, 70);
                ducks.act();

                if (mouseClicked() == true) {
                    if (ducks.getX() - ducks.getHeight() <= getMouseX() && getMouseX() <= ducks.getX() + ducks.getWidth()) {
                        if (ducks.getY() - 35 <= getMouseY() - MENU_BAR_HEIGHT && getMouseY() <= ducks.getY() + 70 + MENU_BAR_HEIGHT) {
                            minigame2Timer = 300;
                            ducks.resetX();
                            ducks.setY((int) (Math.random() * 400 + 45));
                            minigameDuckLabel.setVisible(false);
                            count++;
                        }
                    }
                }
                //printing the timer
                if ((minigame2Timer % 100) == 0) {
                    timerLabel.setText(String.valueOf(minigame2Timer / 100));
                }
                minigame2Timer--;

            } else if (count == 5) {
                int selection = JOptionPane.showConfirmDialog(null, "Would you like to continue?", "Minigame over", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, gameIcon);
                if (selection == 0) {
                    playerWin = true;
                    minigame2Close();
                    gameState = STATE.MAIN_GAME;
                } else {
                    JOptionPane.showMessageDialog(null, "You've Lost, Score: " + CatScrollerGame.getScore(), "", -1, gameIcon);
                    minigame2Close();
                    System.exit(0);
                }
                isGameOver = true;
                stopGame();
            } else {
                JOptionPane.showMessageDialog(null, "You've Lost, Score: " + CatScrollerGame.getScore(), "", -1, gameIcon);
                minigame2Close();
                System.exit(0);
            }
        }
    }

    public boolean getPlayerWin(){
        return playerWin;
    }

    /*
     * Closes the minigame, sets objects to invisible and disposes of window
     */
    public void minigame2Close() {
        counterLabel.setVisible(false);
        ducks.setVisible(false);
        timerLabel.setVisible(false);
        count = 0;
        minigame2Timer = 300;
        dispose();
    }

    /**
     * Description: Displays a menu to play the game, read instructions, or exit the game
     * @throws FileNotFoundException
     */
    public void showMainMenu() throws FileNotFoundException {
        Object[] options = { "PLAY", "INSTRUCTIONS", "EXIT" };
        int selection = JOptionPane.showOptionDialog(null, "WELCOME TO DUCK MINIGAME", "MENU", -1, 3, gameIcon, options, null);
        if (selection == 0)
            gameState = STATE.MINIGAME_2;
        else if (selection == 1) {
            BufferedReader br = new BufferedReader(new FileReader("instructions3.txt"));
            String fileLine = null;
            while (true){
                try {
                    if ((fileLine = br.readLine()) == null) break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
                JOptionPane.showMessageDialog(null, fileLine);
            }
            try {
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return;
        }
        if (selection == 2) {
            System.exit(0);
        }
    }

    @Override
    public void setup() {
        setSize(800,540);
        setDelay(20) ;

        counterLabel = new JLabel();
        Font font = null;
        try {
            font = Font.createFont(Font.TRUETYPE_FONT, new File("MinecraftRegular-Bmg3.otf"));
        } catch (FontFormatException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        counterLabel.setFont(font.deriveFont(24.0f));
        counterLabel.setBounds(0, 25,200,25);
        add(counterLabel);
        counterLabel.setVisible(false);

        timerLabel = new JLabel();
        timerLabel.setFont(font.deriveFont(24.0f));
        timerLabel.setBounds(getWidth() - 200, 25, 200, 25);
        add(timerLabel);
        timerLabel.setVisible(true);

        minigameDuckLabel = new JLabel(new ImageIcon("duck.png"));
        add(minigameDuckLabel);
        minigameDuckLabel.setVisible(false);

        ducks = new ShootDucks();
        ducks.setSize(20, 20);
        ducks.setX(800);
        add(ducks);
        ducks.setVisible(false);

        minigame2Background = new ImageIcon("minigame2_background.png");
        minigame2BackgroundLabel = new JLabel(minigame2Background);
        minigame2BackgroundLabel.setBounds(0, 0, 800, 500);
        add(minigame2BackgroundLabel);
        minigame2BackgroundLabel.setVisible(false);
    }
}