/**
 * Eva Zhang
 * Cactus Object Class
 * ICS4U1 Final Project
 * Jan 22 2023
 */

package csta.ibm.pong;
public class CactusCat extends GameObject{
    @Override
    public void act() {
        setX(getX());
        setY(getY());
    }
    /*
     * Moves in relation to the key presses
     */
    public void moveUp() {
        setY(195);
    }

    public void moveDown() {
        setY(205);
    }

    public void moveRight() {
        setX(305);
    }

    public void moveLeft() {
        setX(295);
    }
}