/**
 * Edwyn Zhou
 * Cat Scroller Game
 * ICS4U1 Final Project
 * Jan 22 2023
 */

package csta.ibm.pong;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Random;

public class CatScrollerGame extends Game{
    private final int GAME_X = 784;
    private final int GAME_Y = 478;
    private Ground ground;
    private Cat cat;
    private final int CAT_Y = GAME_Y - 80;
    private Obstacle bird1;
    private Obstacle bird2;
    private Obstacle cactus1;
    private Obstacle cactus2;
    private boolean running = true;
    private boolean retry = false;
    private boolean minigame_1 = false;
    private boolean minigame_2 = false;
    private boolean speedUp1 = true;
    private boolean speedUp2 = true;
    private boolean speedUp3 = true;
    private static int score = 1000;
    private ArrayList<GameObject> obstacles = new ArrayList<>();
    private JLabel scoreLabel;
    private JLabel catRun1Label;
    private JLabel catRun2Label;
    private JLabel catJumpLabel;
    private JLabel catDuckLabel;
    private JLabel bird1Label;
    private JLabel bird2Label;
    private JLabel cactus1Label;
    private JLabel cactus2Label;
    private Minigame_1 currentMinigame;
    private Minigame_2 currentMinigame2;
    private ImageIcon mainGameBackground = new ImageIcon("mainGameBackground.png");
    private final Color TRANSPARENT = new Color(0, 0, 0, 0);
    STATE gameState = STATE.MENU;
    private ImageIcon gameIcon = new ImageIcon("gameIcon.png");

    public void setup() {
        setSize(800,540);
        // Create images
        ImageIcon catRun1Image = new ImageIcon("catRun1.png");
        catRun1Label = new JLabel(catRun1Image);
        add(catRun1Label);
        catRun1Label.setVisible(true);
        ImageIcon catRun2Image = new ImageIcon("catRun2.png");
        catRun2Label = new JLabel(catRun2Image);
        add(catRun2Label);
        catRun2Label.setVisible(false);
        ImageIcon catJumpImage = new ImageIcon("catJump.png");
        catJumpLabel = new JLabel(catJumpImage);
        add(catJumpLabel);
        catJumpLabel.setVisible(false);
        ImageIcon catDuckImage = new ImageIcon("catDuck.png");
        catDuckLabel = new JLabel(catDuckImage);
        add(catDuckLabel);
        catDuckLabel.setVisible(false);
        ImageIcon bird1Image = new ImageIcon("bird1.png");
        bird1Label = new JLabel(bird1Image);
        add(bird1Label);
        bird1Label.setVisible(true);
        ImageIcon bird2Image = new ImageIcon("bird2.png");
        bird2Label = new JLabel(bird2Image);
        add(bird2Label);
        bird2Label.setVisible(true);
        ImageIcon cactus1Image = new ImageIcon("cactus1.png");
        cactus1Label = new JLabel(cactus1Image);
        add(cactus1Label);
        cactus1Label.setVisible(true);
        ImageIcon cactus2Image = new ImageIcon("cactus2.png");
        cactus2Label = new JLabel(cactus2Image);
        add(cactus2Label);
        cactus2Label.setVisible(true);

        // Create objects
        cat = new Cat(CAT_Y, TRANSPARENT);
        add(cat);
        bird1 = new Obstacle(GAME_X, GAME_Y - 92, 50, 22, TRANSPARENT);
        add(bird1);
        bird2 = new Obstacle(GAME_X, GAME_Y - 97, 60, 27, TRANSPARENT);
        add(bird2);
        cactus1 = new Obstacle(GAME_X, GAME_Y - 66, 60, 58, TRANSPARENT);
        add(cactus1);
        cactus2 = new Obstacle(GAME_X, GAME_Y - 78, 70, 70, TRANSPARENT);
        add(cactus2);
        ground = new Ground(0, GAME_Y - 10, getFieldWidth(), 10, Color.orange);
        add(ground);
        setDelay(20);
        obstacles.add(bird1);
        obstacles.add(bird2);
        obstacles.add(cactus1);
        obstacles.add(cactus2);

        // Create scoreboard
        scoreLabel = new JLabel();
        Font font = null;
        try {
            font = Font.createFont(Font.TRUETYPE_FONT, new File("MinecraftRegular-Bmg3.otf"));
        } catch (FontFormatException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        scoreLabel.setFont(font.deriveFont(24.0f));
        scoreLabel.setBounds(0, 0, 200, 25);
        add(scoreLabel);
        scoreLabel.setVisible(true);

        // Create background
        JLabel backgroundLabel = new JLabel(mainGameBackground);
        backgroundLabel.setBounds(0, 0, getFieldWidth(), getFieldHeight());
        add(backgroundLabel);
        backgroundLabel.setVisible(true);
    }

    public void act() {
        // Launch first minigame and exit back to main game
        if (minigame_1){
            if(currentMinigame.isGameOver) {
                if (currentMinigame.getPlayerWin()) {
                    retry = true;
                    running = true;
                    gameState = STATE.MAIN_GAME;
                }
                minigame_1 = false;
                currentMinigame = null;
            }
            return;
        }
        // Launch second minigame and exit back to main game
        if (minigame_2){
            if(currentMinigame2.isGameOver) {
                if (currentMinigame2.getPlayerWin()) {
                    retry = true;
                    running = true;
                    gameState = STATE.MAIN_GAME;
                }
                minigame_2 = false;
                currentMinigame2 = null;
            }
            return;
        }
        // Menu
        if (gameState == STATE.MENU)
            try {
                showMainMenu();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        // Cat Scroller Game
        if (gameState == STATE.MAIN_GAME) {
            int catY = cat.getCatY();
            if (retry){
                cat.resetCat();
                catY = CAT_Y;
                cat.setY(catY);
                for(GameObject obj : obstacles){
                    respawnObstacle(obj, new Random(), retry);
                }
                retry = false;
            }
            // Set images
            catRun1Label.setBounds(160, catY, 130, 80);
            catRun2Label.setBounds(160, catY, 130, 80);
            catJumpLabel.setBounds(160, catY, 130, 80);
            catDuckLabel.setBounds(160, catY, 130, 80);
            bird1Label.setBounds(bird1.getObstacleX(), bird1.getObstacleY(), 50, 22);
            bird2Label.setBounds(bird2.getObstacleX(), bird2.getObstacleY(), 60, 27);
            cactus1Label.setBounds(cactus1.getObstacleX(), cactus1.getObstacleY(), 60, 58);
            cactus2Label.setBounds(cactus2.getObstacleX(), cactus2.getObstacleY(), 70, 70);

            // Record score
            if (running){
                score++;
                scoreLabel.setText("Score: " + score);
            }

            // Animate cat running (he's running very fast)
            if (score % 2 == 0){
                catRun1Label.setVisible(false);
                catRun2Label.setVisible(true);
            } else{
                catRun2Label.setVisible(false);
                catRun1Label.setVisible(true);
            }

            // Increase speed of game
            if (score > 1500 && speedUp1){
                Obstacle.setSpeed();
                speedUp1 = false;
            } else if (score > 2000 && speedUp2){
                Obstacle.setSpeed();
                speedUp2 = false;
            } else if (score > 2500 && speedUp3){
                Obstacle.setSpeed();
                speedUp3 = false;
            }

            // Obstacle collision
            if (cat.collides(cactus1) || cat.collides(cactus2)){
                setWMove(false);
                setSMove(false);
                running = false;
                int begin = JOptionPane.showConfirmDialog(null, "Cactus Game", "Begin?", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, gameIcon);
                if (begin == 0) {
                    currentMinigame = new Minigame_1();
                    currentMinigame.setVisible(true);
                    currentMinigame.initComponents();
                    minigame_1 = true;
                    return;
                } else{
                    stop();
                    gameState = STATE.MENU;
                    main(new String[0]);
                    return;
                }
            }
            if (cat.collides(bird1) || cat.collides(bird2)){
                setWMove(false);
                setSMove(false);
                running = false;
                int begin = JOptionPane.showConfirmDialog(null, "Bird Game", "Begin?", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, gameIcon);
                if (begin == 0) {
                    currentMinigame2 = new Minigame_2();
                    currentMinigame2.setVisible(true);
                    currentMinigame2.initComponents();
                    minigame_2 = true;
                    return;
                } else{
                    stop();
                    gameState = STATE.MENU;
                    main(new String[0]);
                    return;
                }
            }

            // Spawn obstacles
            for(GameObject obj : obstacles){
                respawnObstacle(obj, new Random(), retry);
            }

            // Jump
            if (WKeyPressed()){
                cat.setIsJumping(true);
            }
            if (cat.getIsJumping()){
                catRun1Label.setVisible(false);
                catRun2Label.setVisible(false);
                catJumpLabel.setVisible(true);
                if(cat.collides(ground)) {
                    catJumpLabel.setVisible(false);
                    catRun1Label.setVisible(true);
                    cat.setIsJumping(false);
                    cat.setY(CAT_Y);
                }
            }

            // Duck
            if (SKeyPressed()){
                catRun1Label.setVisible(false);
                catRun2Label.setVisible(false);
                if(!cat.getIsDucking()){
                    catDuckLabel.setVisible(true);
                    cat.duck();
                }
                cat.setIsDucking(true);
            } else{
                if(cat.getIsDucking()){
                    catDuckLabel.setVisible(false);
                    catRun1Label.setVisible(true);
                    cat.unDuck();
                }
                cat.setIsDucking(false);
            }
        }
    }

    /**
     * Description: Displays a menu to play the game, read instructions, or exit the game
     * @throws FileNotFoundException
     */
    public void showMainMenu() throws FileNotFoundException {
        Object[] options = { "PLAY", "INSTRUCTIONS", "EXIT" };
        int selection = JOptionPane.showOptionDialog(null, "WELCOME TO CAT SCROLLER!", "MENU", -1, 3, gameIcon, options, null);
        if (selection == 0)
            gameState = STATE.MAIN_GAME;
        else if (selection == 1) {
            BufferedReader br = new BufferedReader(new FileReader("instructions.txt"));
            String fileLine = null;
            while (true){
                try {
                    if ((fileLine = br.readLine()) == null) break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
                JOptionPane.showMessageDialog(null, fileLine);
            }
            try {
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return;
        }
        if (selection == 2) {
            System.exit(0);
        }
    }

    /**
     * Description: Calculates and sets new locations for obstacles that have gone offscreen, to be placed back on screen.
     * @param object obstacle that is being replaced
     * @param r random number generator variable
     */
    public void respawnObstacle(GameObject object, Random r, boolean retry){
        if (retry){
            object.setX(getFieldWidth());
        }
        if (object.getX() < 0){
            object.setX(getFieldWidth() + r.nextInt(150));
            boolean isInvalid;
            do{
                isInvalid = false;
                for(GameObject obj : obstacles){
                    if(obj != object){
                        if(obj.collides(object) || (Math.abs(obj.getX() - object.getX()) <= 500
                                && Math.abs(obj.getX() - object.getX()) >= 80)){
                            object.setX(obj.getX() + getFieldWidth() + r.nextInt(900));
                            isInvalid = true;
                        }
                    }
                }
            } while(isInvalid);
        }
    }

    /**
     * Description: Ends cat scroller game, shows final score using JOptionPane
     */
    public void stop(){
        stopGame();
        JOptionPane.showMessageDialog(null, "Game over! Score: " + score);
    }

    public static int getScore(){
       return score;
    }

    public static void main(String[] args) {
        CatScrollerGame c = new CatScrollerGame();
        c.setVisible(true);
        c.initComponents();
    }
}
