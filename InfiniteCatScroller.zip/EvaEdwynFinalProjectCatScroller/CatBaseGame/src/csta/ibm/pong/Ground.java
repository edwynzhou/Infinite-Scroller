/**
 * Edwyn Zhou
 * Ground Object Class
 * ICS4U1 Final Project
 * Jan 22 2023
 */

package csta.ibm.pong;

import java.awt.*;

public class Ground extends GameObject{
    public Ground(int x, int y, int sizeX, int sizeY, Color color){
        setX(x);
        setY(y);
        setSize(sizeX, sizeY);
        setColor(color);
    }
    public void act(){
    }
}
