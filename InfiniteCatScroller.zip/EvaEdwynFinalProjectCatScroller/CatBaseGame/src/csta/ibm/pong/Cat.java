/**
 * Edwyn Zhou
 * Cat Object Class
 * ICS4U1 Final Project
 * Jan 22 2023
 */

package csta.ibm.pong;
import javax.swing.*;
import java.awt.*;

public class Cat extends GameObject{
    private boolean isJumping = false;
    private boolean isDucking = false;
    private final int GRAVITY = 1;
    private int dy = -15;

    public Cat(int y, Color color){
        setSize(110, 70);
        setX(160);
        setY(y);
        setColor(color);
    }

    public void act() {
        if (isJumping){
            setY(getY() + dy);
            dy += GRAVITY;
        } else{
            dy = -15;
        }
    }

    /**
     * Description: resets y position of cat
     */
    public void resetCat(){
        setIsJumping(false);
        dy = -15;
    }

    /**
     * Description: modify boolean state that determines if object is jumping or not
     * @param jump boolean that takes input for whether object is jumping or not
     */
    public void setIsJumping(boolean jump){
        isJumping = jump;
    }

    /**
     * Description: returns boolean value of whether object is jumping or not
     * @return true if jumping, false if not jumping
     */
    public boolean getIsJumping() {
        return isJumping;
    }

    /**
     * Description: modify boolean state that determines if object is ducking or not
     * @param duck boolean that takes input for whether object is jumping or not
     */
    public void setIsDucking(boolean duck){
        isDucking = duck;
    }

    /**
     * Description: modify boolean state that determines if object is ducking or not
     * @return true if ducking, false if not ducking
     */
    public boolean getIsDucking(){
        return isDucking;
    }

    /**
     * Description: Simulates ducking of object, sets size to be smaller in height, changes y location accordingly to move object below obstacles
     */
    public void duck(){
        setSize(110, 60);
        setY(getY() + 10);
    }

    /**
     * Description: Simulates standing of object, sets size to be original object size, change y location accordingly to move object back to original height
     */
    public void unDuck(){
        setY(getY() - 10);
        setSize(110, 70);
    }

    /**
     * Description: Returns y value location of object
     * @return integer location of object on y-axis
     */
    public int getCatY(){
        return getY();
    }
}
