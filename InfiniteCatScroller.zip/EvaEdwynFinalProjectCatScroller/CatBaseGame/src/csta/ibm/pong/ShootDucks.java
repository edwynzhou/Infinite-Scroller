/**
 * Eva Zhang
 * Duck Object Class
 * ICS4U1 Final Project
 * Jan 22 2023
 */

package csta.ibm.pong;

import csta.ibm.pong.GameObject;
import java.lang.Math;
import java.awt.Graphics;

public class ShootDucks extends GameObject{

    private static int dx = -2;
    private boolean move = true;


    @Override
    /*
     * Moves the object across screen
     */
    public void act() {
        setX(getX() + dx);
    }
    public void resetX() {
        setX(750);
    }
}