/**
 * Eva Zhang
 * Minigame 1 (Cactus Game)
 * ICS4U1 Final Project
 * Jan 22 2023
 */

package csta.ibm.pong;
import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class Minigame_1 extends Game{

    private CactusCat cactusCat;
    private JLabel minigame1BackgroundLabel;
    private JLabel counterLabel;
    private ImageIcon minigame1Background;
    private JLabel cactusLabel;
    private JLabel minigameCatLabel;

    private JLabel upArrowLabel;
    private Arrows arrow;
    private JLabel rightArrowLabel;
    private JLabel downArrowLabel;
    private JLabel leftArrowLabel;
    private int [] arrowArray = new int[6];
    private boolean makeArrowSequence = true;
    private boolean playerWin = false;
    public boolean isGameOver = false;

    private JLabel timerLabel;

    private int count = 0;
    STATE gameState = STATE.MENU;


    ImageIcon gameIcon = new ImageIcon("GameIcon.png");

    @Override
    public void act() {
        if (gameState == STATE.MENU) {
            try {
                startGame();
                showMainMenu();

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        minigame1BackgroundLabel.setVisible(true);
        cactusLabel.setVisible(true);
        minigameCatLabel.setVisible(true);
        counterLabel.setVisible(true);

        /*
         * Makes the sequence of arrows
         * makeArrowSequence determines if the array list of arrows should be filled
         */
        if (makeArrowSequence) {
            generateArrowSequence();
            System.out.println(arrowArray.length);
            makeArrowSequence = false;
        }


        if (count < arrowArray.length && arrow.getY() < getHeight()) {
            int currentKeyShown = arrowArray[count];
            cactusLabel.setBounds(0, 0, 800, 500);
            minigameCatLabel.setBounds(300, 200, 100, 130);

            arrow.fall();
            System.out.println(count);
            switch (currentKeyShown) {
                /*
                 * 1 = UP
                 * 2 = RIGHT
                 * 3 = DOWN
                 * 4 = LEFT
                 */
                case 1:
                    upArrowLabel.setVisible(true);
                    upArrowLabel.setBounds(0, arrow.getY(), 63, 65);
                    if (UpKeyPressed() == false) {
                        arrow.reset();
                        cactusCat.moveUp();
                        minigameCatLabel.setBounds(cactusCat.getX(), cactusCat.getY(), 100, 130);
                        cactusLabel.setBounds(10, 0, 800, 540);
                        upArrowLabel.setVisible(false);
                        count++;
                    }
                    break;
                case 2:
                    rightArrowLabel.setVisible(true);
                    rightArrowLabel.setBounds(0, arrow.getY(), 63, 65);
                    if (RightKeyPressed() == false) {
                        arrow.reset();
                        cactusCat.moveRight();
                        minigameCatLabel.setBounds(cactusCat.getX(), cactusCat.getY(), 100, 130);
                        cactusLabel.setBounds(10, 0, 800, 540);
                        rightArrowLabel.setVisible(false);
                        count++;
                    }
                    break;
                case 3:
                    downArrowLabel.setVisible(true);
                    downArrowLabel.setBounds(0, arrow.getY(), 63, 65);
                    if (DownKeyPressed() == false) {
                        arrow.reset();
                        cactusCat.moveDown();
                        minigameCatLabel.setBounds(cactusCat.getX(), cactusCat.getY(), 100, 130);
                        cactusLabel.setBounds(10, 0, 800, 540);
                        downArrowLabel.setVisible(false);
                        count++;
                    }
                    break;
                case 4:
                    leftArrowLabel.setVisible(true);
                    leftArrowLabel.setBounds(0, arrow.getY(), 63, 65);
                    if (LeftKeyPressed() == false) {
                        arrow.reset();
                        cactusCat.moveLeft();
                        minigameCatLabel.setBounds(cactusCat.getX(), cactusCat.getY(), 100, 130);
                        cactusLabel.setBounds(10, 0, 800, 540);
                        leftArrowLabel.setVisible(false);
                        count++;
                    }
                    break;
            }
        } else if (count == arrowArray.length) {
            cactusLabel.setBounds(0, 0, 800, 500);
            arrow.reset();
            int selection = JOptionPane.showConfirmDialog(null, "Would you like to continue?", "Minigame over", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, gameIcon);
            if (selection == 0) {
                playerWin = true;
                minigame1Close();
            } else {
                JOptionPane.showMessageDialog(null, "You've Lost, Score: " + CatScrollerGame.getScore(), "", -1, gameIcon);
                minigame1Close();
                System.exit(0);
            }
            isGameOver = true;
            stopGame();
        } else if (arrow.getY() >= getHeight()){
            JOptionPane.showMessageDialog(null, "You've Lost, Score: " + CatScrollerGame.getScore(), "", -1, gameIcon);
            minigame1Close();
            System.exit(0);
        }
    }

    public boolean getPlayerWin(){
        return playerWin;
    }

    /*
     * Makes the sequence of arrows
     * makeArrowSequence determines if the array list of arrows should be filled
     */
    public void generateArrowSequence() {
        arrowArray[0] = (int) (Math.random() * 4 + 1);
        for (int i = 1; i < arrowArray.length; i++) {

            do {
                arrowArray[i] = (int) (Math.random() * 4 + 1);
            } while(arrowArray[i] == arrowArray[i - 1]);
        }
    }

    /*
     * Closes the minigame, sets objects to invisible and disposes of window
     */
    public void minigame1Close() {
        count = 0;
        arrow.reset();
        makeArrowSequence = true;
        minigame1BackgroundLabel.setVisible(false);
        cactusLabel.setVisible(false);
        minigameCatLabel.setVisible(false);
        counterLabel.setVisible(false);
        dispose();
    }

    /**
     * Description: Displays a menu to play the game, read instructions, or exit the game
     * @throws FileNotFoundException
     */
    public void showMainMenu() throws FileNotFoundException {
        Object[] options = { "PLAY", "INSTRUCTIONS", "EXIT" };
        int selection = JOptionPane.showOptionDialog(null, "WELCOME TO CACTUS MINIGAME", "MENU", -1, 3, gameIcon, options, null);
        if (selection == 0)
            gameState = STATE.MINIGAME_1;
        else if (selection == 1) {
            BufferedReader br = new BufferedReader(new FileReader("instructions2.txt"));
            String fileLine = null;
            while (true){
                try {
                    if ((fileLine = br.readLine()) == null) break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
                JOptionPane.showMessageDialog(null, fileLine);
            }
            try {
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return;
        }
        if (selection == 2) {
            System.exit(0);
        }
    }

    @Override
    public void setup() {
        setSize(800,540);
        setDelay(20) ;
        cactusCat = new CactusCat();
        cactusCat.setSize(10, 10);
        cactusCat.setX(300);
        cactusCat.setY(200);
        add(cactusCat);
        cactusCat.setVisible(false);

        arrow = new Arrows();
        arrow.setSize(20, 20);
        arrow.setX(0);
        arrow.setY(0);
        add(arrow);
        arrow.setVisible(false);

        upArrowLabel = new JLabel(new ImageIcon("upArrow.png"));
        upArrowLabel.setBounds(0, 0, 63, 65);
        add(upArrowLabel);
        upArrowLabel.setVisible(false);

        rightArrowLabel = new JLabel(new ImageIcon("rightArrow.png"));
        rightArrowLabel.setBounds(0, 0, 63, 65);
        add(rightArrowLabel);
        rightArrowLabel.setVisible(false);

        downArrowLabel = new JLabel(new ImageIcon("downArrow.png"));
        downArrowLabel.setBounds(0, 0, 63, 65);
        add(downArrowLabel);
        downArrowLabel.setVisible(false);

        leftArrowLabel = new JLabel(new ImageIcon("leftArrow.png"));
        leftArrowLabel.setBounds(0, 0, 63, 65);
        add(leftArrowLabel);
        leftArrowLabel.setVisible(false);

        minigameCatLabel = new JLabel(new ImageIcon("minigame_cat.png"));
        add(minigameCatLabel);
        minigameCatLabel.setVisible(false);

        cactusLabel = new JLabel(new ImageIcon("cactus.png"));
        add(cactusLabel);
        cactusLabel.setVisible(false);

        minigame1Background = new ImageIcon("minigame1_background.png");
        minigame1BackgroundLabel = new JLabel(minigame1Background);
        minigame1BackgroundLabel.setBounds(0, 0, 800, 500);
        add(minigame1BackgroundLabel);
        minigame1BackgroundLabel.setVisible(false);

        counterLabel = new JLabel();
        counterLabel.setFont(getFont());
        counterLabel.setBounds(0, 0,100,100 );
        add(counterLabel);
        counterLabel.setVisible(false);

        timerLabel = new JLabel();
        timerLabel.setBounds(400, 0, 100, 100);
        add(timerLabel);
        timerLabel.setVisible(true);
    }
}