/*
 * This code is protected under the Gnu General Public License (Copyleft), 2005 by
 * IBM and the Computer Science Teachers of America organization. It may be freely
 * modified and redistributed under educational fair use.
 */
package csta.ibm.pong;

import java.awt.Color;
import java.awt.Rectangle;
import java.awt.event.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.Timer;
import javax.swing.event.MouseInputAdapter;
import javax.swing.JPanel;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import java.awt.Image;
import java.awt.Graphics;

/**
 * An abstract Game class which can be built into Pong.<br>
 * <br>
 * The default controls are for "Player 1" to move left and right with the
 * 'Z' and 'X' keys, and "Playr 2" to move left and right with the 'N' and
 * 'M' keys.<br>
 * <br>
 * Before the Game begins, the <code>setup</code> method is executed. This will
 * allow the programmer to add any objects to the game and set them up. When the
 * game begins, the <code>act</code> method is executed every millisecond. This
 * will allow the programmer to check for user input and respond to it.
 *
 *  @see GameObject
 */
public abstract class Game extends JFrame {
    private boolean _isSetup = false;
    private boolean _initialized = false;
    private ArrayList _ObjectList = new ArrayList();
    private Timer _t;

    //	/**
//	 * <code>true</code> if the 'Z' key is being held down
//	 */
//	private boolean p1Left = false;
//
//	/**
//	 * <code>true</code> if the 'X' key is being held down.
//	 */
//	private boolean p1Right = false;
//
//	/**
//	 * <code>true</code> if the 'N' key is being held down.
//	 */
//	private boolean p2Left = false;
//
//	/**
//	 * <code>true</code> if the 'M' key is being held down.
//	 */
//	private boolean p2Right = false;
    /*
     * Minigame 1
     */
    private boolean pMove = true;

    private boolean rightKeyPressed = true;
    private boolean leftKeyPressed = true;
    private boolean upKeyPressed = true;
    private boolean downKeyPressed = true;
    private boolean wMove = false;
    private boolean sMove = false;
    private int counter = 0;

    /*
     * Minigame 2
     */
    private boolean pShoot = false;
    private int mouseX;
    private int mouseY;

    /**
     * Returns <code>true</code> if the 'Z' key is being pressed down
     *
     * @return <code>true</code> if the 'Z' key is being pressed down
     */
//	public boolean ZKeyPressed() {
//		return p1Left;
//	}
//
//	/**
//	 * Returns <code>true</code> if the 'X' key is being pressed down
//	 *
//	 * @return <code>true</code> if the 'X' key is being pressed down
//	 */
//	public boolean XKeyPressed() {
//		return p1Right;
//	}
//
//	/**
//	 * Returns <code>true</code> if the 'N' key is being pressed down
//	 *
//	 * @return <code>true</code> if the 'N' key is being pressed down
//	 */
//	public boolean NKeyPressed() {
//		return p2Left;
//	}
//
//	/**
//	 * Returns <code>true</code> if the 'M' key is being pressed down
//	 *
//	 * @return <code>true</code> if the 'M' key is being pressed down
//	 */
//	public boolean MKeyPressed() {
//		return p2Right;
//	}

    public boolean mouseClicked() {
        return pShoot;
    }

    public boolean SpaceKeyPressed() {
        return pMove;
    }

    public boolean UpKeyPressed() {
        return upKeyPressed;
    }

    public boolean DownKeyPressed() {
        return downKeyPressed;
    }

    public boolean LeftKeyPressed() {
        return leftKeyPressed;
    }

    public boolean RightKeyPressed() {
        return rightKeyPressed;
    }

    public boolean WKeyPressed(){
        return wMove;
    }
    public boolean SKeyPressed(){
        return sMove;
    }

    public int getMouseX() {
        return mouseX;
    }

    public int getMouseY() {
        return mouseY;
    }


    /**
     * When implemented, this will allow the programmer to initialize the game
     * before it begins running
     *
     * Adding objects to the game and setting their initial positions should be
     * done here.
     *
     * @see GameObject
     */
    public abstract void setup();

    /**
     * When the game begins, this method will automatically be executed every
     * millisecond
     *
     * This may be used as a control method for checking user input and
     * collision between any game objects
     */
    public abstract void act();

    /**
     * Sets up the game and any objects.
     *
     * This method should never be called by anything other than a <code>main</code>
     * method after the frame becomes visible.
     */

    /**
     * Adds a game object to the screen
     *
     * Any added objects will have their <code>act</code> method called every
     * millisecond
     *
     * @param o		the <code>GameObject</code> to add.
     * @see	GameObject#act()
     */

    private static boolean isVisible = true;

    public static boolean getIsVisible() {
        return isVisible;
    }

    public void setIsVisible(boolean visible) {
        isVisible = visible;
    }

    public void add(GameObject o) {
        _ObjectList.add(o);
        getContentPane().add(o);
        getContentPane().repaint();
    }

    /**
     * Removes a game object from the screen
     *
     * @param o		the <code>GameObject</code> to remove
     * @see	GameObject
     */
    public void remove(GameObject o) {
        _ObjectList.remove(o);
        getContentPane().remove(o);
    }

    /**
     * Sets the millisecond delay between calls to <code>act</code> methods.
     *
     * Increasing the delay will make the game run "slower." The default delay
     * is 1 millisecond.
     *
     * @param delay	the number of milliseconds between calls to <code>act</code>
     * @see Game#act()
     * @see GameObject#act()
     */
    public void setDelay(int delay) {
        _t.setDelay(delay);
    }

    /**
     * Sets the background color of the playing field
     *
     * The default color is black
     *
     * @see java.awt.Color
     */
    public void setBackground(Color c) {
        getContentPane().setBackground(c);
    }

    /**
     * The default constructor for the game.
     *
     * The default window size is 400x400
     */

//	public void JPanelWithBackground(String fileName) throws IOException {
//		background = ImageIO.read(new File(fileName));
//		frame.add(background);
//	}


    public void initComponents() {
        //getContentPane().setBackground(Color.blue);
        setup();
        for (int i = 0; i < _ObjectList.size(); i++) {
            GameObject o = (GameObject)_ObjectList.get(i);
            o.repaint();
        }
        //frame.getContentPane().add(new JPanelWithBackground("download.jpeg"));
        _t.start();
    }


    public Game() {
        setSize(800, 540);

        getContentPane().setBackground(Color.blue);
        getContentPane().setLayout(null);
        JMenuBar menuBar = new JMenuBar();

        JMenu menuFile = new JMenu("File");
        JMenuItem menuFileExit = new JMenuItem("Exit");
        menuBar.add(menuFile);
        menuFile.add(menuFileExit);
        setJMenuBar(menuBar);
        setTitle("Game");

        // Add window listener.
        addWindowListener (
                new WindowAdapter() {
                    public void windowClosing(WindowEvent e) {
                        System.exit(0);
                    }
                }
        );
        menuFileExit.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        System.exit(0);
                    }
                }
        );
        _t = new Timer(1, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                act();
                for (int i = 0; i < _ObjectList.size(); i++) {
                    GameObject o = (GameObject)_ObjectList.get(i);
                    o.act();
                }
            }
        });
        addKeyListener(new KeyListener() {
            public void keyTyped(KeyEvent e) {
                switch (e.getKeyChar()) {
                    case 'k' : counter++; pMove = true; break;
                }

            }

            public void keyPressed(KeyEvent e) {
                int pressed = e.getKeyCode();
                switch (pressed) {
                    case ' ' :  pMove = false; break;
                    case KeyEvent.VK_UP : upKeyPressed = false; break;
                    case KeyEvent.VK_DOWN : downKeyPressed = false; break;
                    case KeyEvent.VK_LEFT : leftKeyPressed = false; break;
                    case KeyEvent.VK_RIGHT : rightKeyPressed = false; break;
                    case 'W' : wMove = true; break;
                    case 'S' : sMove = true; break;
                }
            }

            public void keyReleased(KeyEvent e) {
                int released = e.getKeyCode();
                switch (released) {
                    case ' ' :  pMove = true; counter++; break;
                    case KeyEvent.VK_UP : upKeyPressed = true; break;
                    case KeyEvent.VK_DOWN : downKeyPressed = true; break;
                    case KeyEvent.VK_LEFT : leftKeyPressed = true; break;
                    case KeyEvent.VK_RIGHT : rightKeyPressed = true; break;
                    case 'W' : wMove = false; break;
                    case 'S' : sMove = false; break;
                }
            }
        });
        this.addMouseListener(new MouseInputAdapter() {
            public void mousePressed(MouseEvent e) {
                pShoot = true;
                mouseX = (int)e.getPoint().getX();
                mouseY = (int)e.getPoint().getY();
            }
            public void mouseReleased(MouseEvent e) {
                pShoot = false;
            }
        });
    }

    /**
     * Starts updates to the game
     *
     * The game should automatically start.
     *
     * @see Game#stopGame()
     */
    public void startGame() {
        _t.start();
    }


    /**
     * Stops updates to the game
     *
     * This can act like a "pause" method
     *
     * @see Game#startGame()
     */
    public void stopGame() {
        _t.stop();
    }

    /**
     * Displays a dialog that says "Player 1 Wins!"
     *
     */
    public void p1Wins() {
        _WinDialog d = new _WinDialog(this, "Player 1 Wins!");
        d.setVisible(true);
    }

    /**
     * Displays a dialog that says "Player 2 Wins!"
     *
     */
    public void p2Wins() {
        _WinDialog d = new _WinDialog(this, "Player 2 Wins!");
        d.setVisible(true);
    }

    /**
     * Gets the pixel width of the visible playing field
     *
     * @return	a width in pixels
     */
    public int getFieldWidth() {
        return getContentPane().getBounds().width;
    }

    /**
     * Gets the pixel height of the visible playing field
     *
     * @return a height in pixels
     */
    public int getFieldHeight() {
        return getContentPane().getBounds().height;
    }

    public int getCounter() {
        return counter;
    }

    public void resetCounter() {
        counter = 0;
    }

    public void setWMove(boolean b){
        wMove = b;
    }

    public void setSMove(boolean b){
        sMove = b;
    }

    class _WinDialog extends JDialog {
        JButton ok = new JButton("OK");
        _WinDialog(JFrame owner, String title) {
            super(owner, title);
            Rectangle r = owner.getBounds();
            setSize(200, 100);
            setLocation(r.x + r.width / 2 - 100, r.y + r.height / 2 - 50);
            getContentPane().add(ok);
            ok.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    _WinDialog.this.setVisible(false);
                }
            });
        }
    }
}